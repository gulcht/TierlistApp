package com.mobile101.tierlistAPI.tierlist.payload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TierPayload {
    private String name;
    private String color;
}
