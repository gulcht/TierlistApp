package com.mobile101.tierlistAPI.tierlist.payload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ItemsetPayload {
    private String name;
    private String image;    
}
