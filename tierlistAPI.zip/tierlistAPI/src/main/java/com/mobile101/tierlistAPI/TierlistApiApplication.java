package com.mobile101.tierlistAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TierlistApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TierlistApiApplication.class, args);
	}

}
