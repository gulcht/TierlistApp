package com.mobile101.tierlistAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TierlistApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
